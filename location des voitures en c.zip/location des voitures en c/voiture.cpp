#include <stdio.h>
#include <string.h> // Pour strcmp()

#define MAX_VOITURES 10

// Structure de voiture
struct voiture {
    char matricule[20];
    char marque[50];
    char modele[50];
    int annee;
    float prix_par_jour;
    int est_louee;
};

// Fonction pour ajouter une voiture
void ajouterVoiture(struct voiture voitures[], int *nb_voitures) {
    if (*nb_voitures >= MAX_VOITURES) {
        printf("Limite maximale de voitures atteinte.\n");
        return;
    }

    struct voiture v;

    printf("Entrer le matricule : ");
    scanf("%s", v.matricule);

    // V�rification unicit� du matricule
    for (int i = 0; i < *nb_voitures; i++) {
        if (strcmp(voitures[i].matricule, v.matricule) == 0) {
            printf("Erreur : une voiture avec ce matricule existe d�j�.\n");
            return;
        }
    }

    printf("Entrer la marque : ");
    scanf("%s", v.marque);
    printf("Entrer le mod�le : ");
    scanf("%s", v.modele);
    printf("Entrer l'ann�e : ");
    scanf("%d", &v.annee);
    printf("Entrer le prix par jour : ");
    scanf("%f", &v.prix_par_jour);
    v.est_louee = 0;

    voitures[*nb_voitures] = v;
    (*nb_voitures)++;

    printf("Voiture ajout�e avec succ�s.\n");
}

// Fonction pour louer une voiture par matricule
void louerVoiture(struct voiture voitures[], int nb_voitures) {
    char matricule[20];
    printf("Entrer le matricule de la voiture � louer : ");
    scanf("%s", matricule);

    for (int i = 0; i < nb_voitures; i++) {
        if (strcmp(voitures[i].matricule, matricule) == 0) {
            if (voitures[i].est_louee) {
                printf("Cette voiture est d�j� lou�e.\n");
            } else {
                voitures[i].est_louee = 1;
                printf("Voiture lou�e avec succ�s.\n");
            }
            return;
        }
    }

    printf("Voiture non trouv�e.\n");
}

// Fonction pour rendre une voiture
void rendreVoiture(struct voiture voitures[], int nb_voitures) {
    char matricule[20];
    printf("Entrer le matricule de la voiture � rendre : ");
    scanf("%s", matricule);

    for (int i = 0; i < nb_voitures; i++) {
        if (strcmp(voitures[i].matricule, matricule) == 0) {
            if (!voitures[i].est_louee) {
                printf("Cette voiture n'est pas lou�e.\n");
            } else {
                voitures[i].est_louee = 0;
                printf("Voiture rendue avec succ�s.\n");
            }
            return;
        }
    }

    printf("Voiture non trouv�e.\n");
}

// Afficher toutes les voitures
void afficherVoitures(struct voiture voitures[], int nb_voitures) {
    printf("\nListe des voitures :\n");
    for (int i = 0; i < nb_voitures; i++) {
        printf("%d - [%s] %s %s, %d, %.2f MAD/jour - %s\n",
            i + 1,
            voitures[i].matricule,
            voitures[i].marque,
            voitures[i].modele,
            voitures[i].annee,
            voitures[i].prix_par_jour,
            voitures[i].est_louee ? "LOU�E" : "DISPONIBLE"
        );
    }
}

// Fonction principale
int main() {
    struct voiture voitures[MAX_VOITURES];
    int nb_voitures = 0;
    int choix;

    do {
        printf("\n=== MENU LOCATION DE VOITURES ===\n");
        printf("1. Ajouter une voiture\n");
        printf("2. Louer une voiture\n");
        printf("3. Rendre une voiture\n");
        printf("4. Afficher toutes les voitures\n");
        printf("5. Quitter\n");
        printf("Votre choix : ");
        scanf("%d", &choix);

        switch (choix) {
            case 1:
                ajouterVoiture(voitures, &nb_voitures);
                break;
            case 2:
                louerVoiture(voitures, nb_voitures);
                break;
            case 3:
                rendreVoiture(voitures, nb_voitures);
                break;
            case 4:
                afficherVoitures(voitures, nb_voitures);
                break;
            case 5:
                printf("Au revoir !\n");
                break;
            default:
                printf("Choix invalide.\n");
        }

    } while (choix != 5);

    return 0;
}
